# Detecting Anomalies in U.S. Vehicle Sales

Uses monthly U.S. total vehicle sales (FRED series **TOTALNSA**, thousands of units, not seasonally adjusted, Jan 2000 – Jan 2026) and Facebook Prophet to find and model anomalies.

**What's covered**
1. Baseline Prophet forecast
2. Modeling anomalies as special events: 2001 0% financing promo, 2005 employee pricing promo, 2020 COVID lockdowns
3. Seasonal-trend decomposition: trend vs. seasonality anomalies (2008 financial crisis)
4. Changepoint analysis
5. Forecast uncertainty: baseline vs. special-events model
6. Applying a custom event to a future date (simulated 2027 promotion)

**Files**
- `vehicle_sales_anomalies.ipynb`: analysis notebook
- `TOTALNSA.csv`: source data (FRED)
